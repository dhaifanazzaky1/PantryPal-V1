const baseUrl = "http://localhost:3000" // ganti sesuai url server
export default baseUrl